# AKITAN 1st Project - made by Akira (Android WebView app)

Discord web in a WebView with ONE crimson GUI that hosts both voice engines:
- **AKIRA** mode: GAIN / TONE / BASS / DIST / SPACE / VOICE / STEREO / PRESETS, BYPASS, MUTE, RESET
- **BLAKE** mode: all BlakeCord V4 tabs (loud-mic engine, EQ, FX, presets, MP3 player, profiles, settings)
- Animated portrait (blinks, eyes move, breathing, follows your finger) in the header, launcher bubble and BlakeCord boot screen
- Side up/down buttons (both edges): tap = page scroll, hold = smooth scroll

Both engines stay active in the call chain (Akira first, then BlakeCord). Use each one's bypass/reset to turn it off.

## Build
GitHub: upload folder, run "Build Akira APK" action. Or Android Studio: open folder, Build > Build APK(s).

## Files (app/src/main/assets)
- `akira-engine.js` original Akira engine + UI (unchanged)
- `blakecord-engine.js` BlakeCord engine + UI (audio code unchanged, recolored)
- `unified-shell.js` panel, portrait animation, mode switch, side buttons
- `portrait-data.js` the portrait image (embedded)
- `ua-patch.js` desktop-browser identity so Discord allows calls

## Extras
- Tab switches make her react: a hum ("mhhmmmm"), an "ahh", or she says the tab name (local speaker only, never in the call). She also nods and blinks.
- Spectrum strip reacts to your mic, embers float over her banner, scrolling "ULTIMATE GOD MODE / PC DESTROYER" ticker (visual only), glitch title, spinning ring on the launcher.
