/* AKIRA ENGINE - combined voice engine + tabbed panel for the Akira WebView app.
   Merges the feature sets of the Cord / Slayer / Spectral / Hollow / Devil / Blake / Bloodymoon / Worst series
   into one deduplicated chain. Everything is off (unity, 0 dB) by default. */
(function () {
  'use strict';
  if (window.__AKIRA_ENGINE__) return;
  window.__AKIRA_ENGINE__ = true;

  var LS_KEY = 'akira:v1';
  var dbLin = function (d) { return Math.pow(10, d / 20); };
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };

  /* ------------------------------------------------------------------ *
   *  PARAMETERS  (tab, id, label, min, max, default, display)
   * ------------------------------------------------------------------ */
  var TABS = ['GAIN', 'TONE', 'BASS', 'DIST', 'SPACE', 'VOICE', 'STEREO', 'PRESETS'];
  var dB = function (k) { return function (v) { return '+' + (v * k).toFixed(0) + ' dB'; }; };
  var pc = function (v) { return v.toFixed(0) + '%'; };
  var sdb = function (v) { return (v > 0 ? '+' : '') + v.toFixed(1) + ' dB'; };

  var DEFS = [
    // GAIN
    ['GAIN', 'pre',   'AKIRA PRE-AMP',    0, 100, 0, dB(0.3)],
    ['GAIN', 'g1',    'DEMON GAIN 1',     0, 100, 0, dB(0.3)],
    ['GAIN', 'g2',    'DESTROYER GAIN 2', 0, 100, 0, dB(0.3)],
    ['GAIN', 'g3',    'REAPER GAIN 3',    0, 100, 0, dB(0.3)],
    ['GAIN', 'g4',    'SLAYER GAIN 4',    0, 100, 0, dB(0.3)],
    ['GAIN', 'omega', 'AKIRA OMEGA',      0, 100, 0, dB(0.4)],
    ['GAIN', 'nuke',  'AKIRA NUKE',       0, 100, 0, pc],
    ['GAIN', 'gate',  'AKIRA GATE',       0, 100, 0, function (v) { return v ? (-90 + v * 0.6).toFixed(0) + ' dB' : 'OFF'; }],
    ['GAIN', 'master','AKIRA OUTPUT',     0, 200, 100, pc],
    ['GAIN', 'limiter','AKIRA SOFT LIMITER', 0, 1, 0, 'toggle'],
    // TONE
    ['TONE', 'bass',   'BASS',            -12, 12, 0, sdb],
    ['TONE', 'mid',    'MID',             -12, 12, 0, sdb],
    ['TONE', 'treble', 'TREBLE',          -12, 12, 0, sdb],
    ['TONE', 'sharp',  'AKIRA SHARP',     0, 100, 0, pc],
    ['TONE', 'scream', 'DEMON SCREAM',    0, 100, 0, pc],
    ['TONE', 'laser',  'AKIRA LASER',     0, 100, 0, pc],
    ['TONE', 'hiss',   'VENOM HISS',      0, 100, 0, pc],
    ['TONE', 'air',    'AKIRA AIR',       0, 100, 0, pc],
    ['TONE', 'bassKill','BASS SLAYER',    0, 100, 0, function (v) { return v ? (20 * Math.pow(20, v / 100)).toFixed(0) + ' Hz' : 'OFF'; }],
    // BASS
    ['BASS', 'quake',  'AKIRA QUAKE',     0, 100, 0, pc],
    ['BASS', 'sub',    'SUB DEMON',       0, 100, 0, pc],
    ['BASS', 'tremor', 'AKIRA TREMOR',    0, 100, 0, pc],
    ['BASS', 'doom',   'DOOM RESONANCE',  0, 100, 0, pc],
    ['BASS', 'breath', 'TITAN BREATH',    0, 100, 0, pc],
    ['BASS', 'fat',    'AKIRA FAT',       0, 100, 0, pc],
    // DIST
    ['DIST', 'sat',    'AKIRA SATURATION',0, 100, 0, pc],
    ['DIST', 'asym',   'DEMON CLIP',      0, 100, 0, pc],
    ['DIST', 'fold',   'AKIRA FOLD',      0, 100, 0, pc],
    ['DIST', 'blood',  'BLOOD BOIL',      0, 100, 0, pc],
    ['DIST', 'crush',  'AKIRA CRUSH',     0, 100, 0, pc],
    ['DIST', 'noise',  'STATIC WRATH',    0, 100, 0, pc],
    ['DIST', 'comp',   'AKIRA COMPRESSOR',0, 100, 0, pc],
    ['DIST', 'brick',  'AKIRA BRICKWALL', 0, 100, 0, pc],
    // SPACE
    ['SPACE', 'revMix',  'AKIRA ROOM',    0, 100, 0, pc],
    ['SPACE', 'revSize', 'ROOM SIZE',     1, 40, 12, function (v) { return (v / 10).toFixed(1) + ' s'; }],
    ['SPACE', 'echoMix', 'AKIRA ECHO',    0, 100, 0, pc],
    ['SPACE', 'echoTime','ECHO TIME',     40, 800, 280, function (v) { return v.toFixed(0) + ' ms'; }],
    ['SPACE', 'echoFb',  'ECHO FEEDBACK', 0, 90, 35, pc],
    ['SPACE', 'phaser',  'PSYCHO PHASE',  0, 100, 0, pc],
    ['SPACE', 'ring',    'AKIRA RING',    0, 100, 0, pc],
    ['SPACE', 'ringFreq','RING FREQUENCY',20, 2000, 120, function (v) { return v.toFixed(0) + ' Hz'; }],
    // VOICE
    ['VOICE', 'pitch', 'AKIRA PITCH',     -12, 12, 0, function (v) { return (v > 0 ? '+' : '') + v.toFixed(1) + ' st'; }],
    ['VOICE', 'dbl',   'VOCAL DOUBLER',   0, 100, 0, pc],
    // STEREO
    ['STEREO', 'width', 'STEREO WIDTH',   0, 200, 100, pc],
    ['STEREO', 'pan',   'PAN',           -100, 100, 0, function (v) { return v === 0 ? 'C' : (v < 0 ? 'L' + (-v) : 'R' + v); }],
    ['STEREO', 'invert','PHASE FLIP',     0, 1, 0, 'toggle'],
    ['STEREO', 'mono',  'MONO',           0, 1, 0, 'toggle'],
    ['STEREO', 'opus',  'STEREO OPUS (restart call)', 0, 1, 1, 'toggle']
  ].map(function (d) { return { tab: d[0], id: d[1], label: d[2], min: d[3], max: d[4], def: d[5], disp: d[6] }; });

  var DEFMAP = {};
  DEFS.forEach(function (d) { DEFMAP[d.id] = d; });

  var P = {};                               // live parameter values
  DEFS.forEach(function (d) { P[d.id] = d.def; });
  var flags = { bypass: false, mute: false };
  try { var saved = JSON.parse(localStorage.getItem(LS_KEY) || 'null'); if (saved && saved.P) { for (var k in saved.P) if (k in P) P[k] = +saved.P[k]; } } catch (e) {}
  function persist() { try { localStorage.setItem(LS_KEY, JSON.stringify({ P: P })); } catch (e) {} }

  var PRESETS = {
    'DEFAULT':    function () { return {}; },
    'LOUD':       function () { return { pre: 20, g1: 30, g2: 20, nuke: 15, sharp: 20, comp: 30, limiter: 1 }; },
    'SUPER LOUD': function () { return { pre: 30, g1: 50, g2: 40, g3: 30, nuke: 30, sharp: 30, comp: 50, brick: 20 }; },
    'MAX':        function () { return { pre: 40, g1: 60, g2: 60, g3: 60, g4: 60, omega: 60, nuke: 60, brick: 40 }; },
    'CLEAN':      function () { return { pre: 10, g1: 10, comp: 25, bass: -2, treble: 2, gate: 20, limiter: 1 }; },
    'DEEP VOICE': function () { return { pitch: -5, bass: 4, g1: 15, comp: 20, limiter: 1 }; },
    'KID VOICE':  function () { return { pitch: 6, treble: 3, g1: 10, limiter: 1 }; },
    'DEMON':      function () { return { pitch: -7, ring: 25, ringFreq: 70, blood: 35, doom: 40, revMix: 25, revSize: 20, g1: 25, limiter: 1 }; },
    'ROBOT':      function () { return { ring: 100, ringFreq: 55, echoMix: 20, echoTime: 18, echoFb: 40, g1: 15, limiter: 1 }; },
    'ALIEN':      function () { return { pitch: 4, ring: 45, ringFreq: 380, phaser: 60, revMix: 20, g1: 15, limiter: 1 }; },
    'GIANT':      function () { return { pitch: -10, bass: 6, revMix: 30, revSize: 25, g1: 20, limiter: 1 }; },
    'HELIUM':     function () { return { pitch: 10, treble: 4, g1: 10, limiter: 1 }; }
  };

  /* ------------------------------------------------------------------ *
   *  AUDIO WORKLET (front / back / out)
   * ------------------------------------------------------------------ */
  var WORKLET = String.raw`
const TAU = Math.PI * 2;
class AkiraFront extends AudioWorkletProcessor {
  constructor() {
    super();
    this.p = { gate: 0, gain: 1, pitch: 1, ringMix: 0, ringFreq: 100, mute: 0 };
    this.g = 1; this.gs = 1; this.env = 0; this.hold = 0; this.pp = 0; this.rt = 0;
    this.N = 16384; this.W = 1920; this.w = 0;
    this.b0 = new Float32Array(this.N); this.b1 = new Float32Array(this.N);
    this.port.onmessage = (e) => { Object.assign(this.p, e.data); };
  }
  rd(b, pos) { const N = this.N - 1; const ip = Math.floor(pos); const f = pos - ip; return b[ip & N] * (1 - f) + b[(ip + 1) & N] * f; }
  process(inp, out) {
    const i = inp[0], o = out[0]; if (!o || !o.length) return true;
    const L = o[0].length, p = this.p, sr = sampleRate, N = this.N - 1, W = this.W;
    for (let n = 0; n < L; n++) {
      let x0 = i && i[0] ? i[0][n] : 0, x1 = i && i[1] ? i[1][n] : x0;
      const lvl = Math.max(Math.abs(x0), Math.abs(x1));
      this.env = lvl > this.env ? lvl : this.env + (lvl - this.env) * 0.0004;
      let t = 1;
      if (p.gate > 0) { if (this.env > p.gate) this.hold = (sr * 0.12) | 0; if (this.hold > 0) { this.hold--; t = 1; } else t = 0; }
      this.gs += (t - this.gs) * (t > this.gs ? 0.01 : 0.0015);
      this.g += (p.gain - this.g) * 0.002;
      const gg = p.mute ? 0 : this.g * this.gs;
      x0 *= gg; x1 *= gg;
      x0 = x0 > 8 ? 8 : x0 < -8 ? -8 : x0; x1 = x1 > 8 ? 8 : x1 < -8 ? -8 : x1;
      this.b0[this.w] = x0; this.b1[this.w] = x1;
      if (p.pitch !== 1) {
        this.pp += (1 - p.pitch) / W; this.pp -= Math.floor(this.pp);
        const a = this.pp, b = (a + 0.5) % 1;
        const wa = 0.5 - 0.5 * Math.cos(TAU * a), wb = 0.5 - 0.5 * Math.cos(TAU * b);
        const da = a * W + 2, db = b * W + 2;
        x0 = this.rd(this.b0, this.w - da) * wa + this.rd(this.b0, this.w - db) * wb;
        x1 = this.rd(this.b1, this.w - da) * wa + this.rd(this.b1, this.w - db) * wb;
      }
      this.w = (this.w + 1) & N;
      if (p.ringMix > 0) {
        const r = Math.sin(this.rt); this.rt += TAU * p.ringFreq / sr; if (this.rt > TAU) this.rt -= TAU;
        const m = p.ringMix; x0 = x0 * (1 - m) + x0 * r * m; x1 = x1 * (1 - m) + x1 * r * m;
      }
      o[0][n] = x0; if (o[1]) o[1][n] = x1;
    }
    return true;
  }
}
class AkiraBack extends AudioWorkletProcessor {
  constructor() {
    super();
    this.p = { sat: 0, fold: 0, asym: 0, blood: 0, crush: 0, noise: 0, fat: 0, nuke: 0, breath: 0 };
    this.h = [0, 0]; this.cnt = 0; this.lfo = 0;
    this.port.onmessage = (e) => { Object.assign(this.p, e.data); };
  }
  proc(x, c, hold) {
    const p = this.p;
    if (p.sat > 0) { const d = 1 + p.sat * 20; x = Math.tanh(x * d) / Math.tanh(d); }
    if (p.fat > 0) x += p.fat * 0.5 * Math.tanh(x * 4);
    if (p.fold > 0) { const y = x * (1 + p.fold * 6); x = Math.asin(Math.sin(y * 1.5707963)) * 0.63662; }
    if (p.asym > 0) { const c1 = 1 - 0.7 * p.asym; if (x > c1) x = c1; x = x * (1 + p.asym * 0.5); }
    if (p.blood > 0) { const m = p.blood * 0.7; x = x * (1 - m) + Math.tanh(x * (1 + 30 * p.blood)) * m; }
    if (p.crush > 0) {
      if (hold) { const st = Math.pow(2, 1 - (16 - 13 * p.crush)); this.h[c] = Math.round(x / st) * st; }
      x = this.h[c];
    }
    if (p.nuke > 0) { const d = 1 + p.nuke * 60; x = Math.tanh(x * d) * 1.15; }
    if (p.noise > 0) x += (Math.random() - 0.5) * p.noise * 0.3;
    return x;
  }
  process(inp, out) {
    const i = inp[0], o = out[0]; if (!o || !o.length) return true;
    const L = o[0].length, p = this.p;
    const fac = p.crush > 0 ? 1 + Math.floor(p.crush * 8) : 1;
    for (let n = 0; n < L; n++) {
      this.cnt++; const hold = this.cnt >= fac; if (hold) this.cnt = 0;
      let gain = 1;
      if (p.breath > 0) { this.lfo += TAU * 0.35 / sampleRate; if (this.lfo > TAU) this.lfo -= TAU; gain = 1 - p.breath * 0.5 * (1 + Math.sin(this.lfo)); }
      let x0 = i && i[0] ? i[0][n] : 0, x1 = i && i[1] ? i[1][n] : x0;
      o[0][n] = this.proc(x0 * gain, 0, hold); if (o[1]) o[1][n] = this.proc(x1 * gain, 1, hold);
    }
    return true;
  }
}
class AkiraOut extends AudioWorkletProcessor {
  constructor() {
    super();
    this.p = { width: 1, mono: 0, invert: 0, master: 1, brick: 0, soft: 0, mute: 0 };
    this.m = 1; this.xm = [0, 0]; this.ym = [0, 0];
    this.port.onmessage = (e) => { Object.assign(this.p, e.data); };
  }
  process(inp, out) {
    const i = inp[0], o = out[0]; if (!o || !o.length) return true;
    const L = o[0].length, p = this.p, c = 1 - 0.8 * p.brick;
    for (let n = 0; n < L; n++) {
      let l = i && i[0] ? i[0][n] : 0, r = i && i[1] ? i[1][n] : l;
      const mid = (l + r) * 0.5, side = (l - r) * 0.5 * p.width;
      if (p.mono) { l = mid; r = mid; } else { l = mid + side; r = mid - side; }
      this.m += (p.master - this.m) * 0.005;
      const k = p.mute ? 0 : this.m * (p.invert ? -1 : 1);
      l *= k; r *= k;
      let y0 = l - this.xm[0] + 0.995 * this.ym[0]; this.xm[0] = l; this.ym[0] = y0;
      let y1 = r - this.xm[1] + 0.995 * this.ym[1]; this.xm[1] = r; this.ym[1] = y1;
      if (p.brick > 0) { y0 = (y0 > c ? c : y0 < -c ? -c : y0) / c; y1 = (y1 > c ? c : y1 < -c ? -c : y1) / c; }
      if (p.soft) { y0 = Math.tanh(y0); y1 = Math.tanh(y1); } else { y0 = y0 > 1 ? 1 : y0 < -1 ? -1 : y0; y1 = y1 > 1 ? 1 : y1 < -1 ? -1 : y1; }
      if (y0 !== y0) y0 = 0; if (y1 !== y1) y1 = 0;
      o[0][n] = y0; if (o[1]) o[1][n] = y1;
    }
    return true;
  }
}
registerProcessor('akira-front', AkiraFront);
registerProcessor('akira-back', AkiraBack);
registerProcessor('akira-out', AkiraOut);
`;

  var workletLoaded = new WeakMap();
  function loadWorklet(ctx) {
    if (workletLoaded.has(ctx)) return workletLoaded.get(ctx);
    var url = URL.createObjectURL(new Blob([WORKLET], { type: 'application/javascript' }));
    var pr = ctx.audioWorklet.addModule(url).then(function () { URL.revokeObjectURL(url); });
    workletLoaded.set(ctx, pr);
    return pr;
  }
  function mkWorklet(ctx, name) {
    return new AudioWorkletNode(ctx, name, { numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [2], channelCount: 2, channelCountMode: 'explicit', channelInterpretation: 'speakers' });
  }

  /* ------------------------------------------------------------------ *
   *  CHAIN
   * ------------------------------------------------------------------ */
  var EQ = [
    ['hpf', 'highpass', 20, 0.7], ['bass', 'lowshelf', 120, 0.7], ['mid', 'peaking', 1000, 0.9], ['treble', 'highshelf', 6000, 0.7],
    ['sharp', 'highshelf', 4000, 0.7], ['scream', 'peaking', 3000, 1.2], ['laser', 'peaking', 7500, 3], ['hiss', 'peaking', 9500, 1.5],
    ['air', 'highshelf', 12000, 0.7], ['quake', 'lowshelf', 70, 0.7], ['sub', 'peaking', 45, 1], ['tremor', 'peaking', 90, 2], ['doom', 'peaking', 140, 8]
  ];

  function makeIR(ctx, seconds) {
    var len = Math.max(1, Math.floor(ctx.sampleRate * seconds));
    var buf = ctx.createBuffer(2, len, ctx.sampleRate);
    for (var c = 0; c < 2; c++) {
      var d = buf.getChannelData(c);
      for (var i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3.2);
    }
    return buf;
  }

  async function buildChain(ctx, srcNode, destNode) {
    await loadWorklet(ctx);
    var C = { ctx: ctx, nodes: {} };
    var front = mkWorklet(ctx, 'akira-front'), back = mkWorklet(ctx, 'akira-back'), outp = mkWorklet(ctx, 'akira-out');
    var inGain = ctx.createGain();
    srcNode.connect(inGain); inGain.connect(front);
    var prev = front, filters = {};
    EQ.forEach(function (e) {
      var f = ctx.createBiquadFilter(); f.type = e[1]; f.frequency.value = e[2]; f.Q.value = e[3]; f.gain.value = 0;
      prev.connect(f); prev = f; filters[e[0]] = f;
    });
    prev.connect(back);
    // parallel section after distortion
    var sum = ctx.createGain(); back.connect(sum);
    var conv = ctx.createConvolver(); var revWet = ctx.createGain(); revWet.gain.value = 0;
    back.connect(conv); conv.connect(revWet); revWet.connect(sum);
    var dly = ctx.createDelay(1.0), fb = ctx.createGain(), echoWet = ctx.createGain(); echoWet.gain.value = 0; fb.gain.value = 0.35; dly.delayTime.value = 0.28;
    back.connect(dly); dly.connect(fb); fb.connect(dly); dly.connect(echoWet); echoWet.connect(sum);
    // phaser
    var phWet = ctx.createGain(); phWet.gain.value = 0; var lfo = ctx.createOscillator(); lfo.frequency.value = 0.45; lfo.start();
    var pp = back;
    [[300, 200], [700, 500], [1500, 1000], [3000, 2000]].forEach(function (a) {
      var ap = ctx.createBiquadFilter(); ap.type = 'allpass'; ap.frequency.value = a[0]; ap.Q.value = 0.7;
      var lg = ctx.createGain(); lg.gain.value = a[1]; lfo.connect(lg); lg.connect(ap.frequency);
      pp.connect(ap); pp = ap;
    });
    pp.connect(phWet); phWet.connect(sum);
    // doubler
    var dblWet = ctx.createGain(); dblWet.gain.value = 0; var lfo2 = ctx.createOscillator(); lfo2.frequency.value = 0.7; lfo2.start();
    [0.017, 0.029].forEach(function (t, k) {
      var d = ctx.createDelay(0.1); d.delayTime.value = t; var lg = ctx.createGain(); lg.gain.value = 0.002 * (k ? -1 : 1);
      lfo2.connect(lg); lg.connect(d.delayTime); back.connect(d); d.connect(dblWet);
    });
    dblWet.connect(sum);
    // dynamics, pan, out
    var comp = ctx.createDynamicsCompressor(); comp.threshold.value = 0; comp.ratio.value = 1; comp.knee.value = 6; comp.attack.value = 0.003; comp.release.value = 0.15;
    var makeup = ctx.createGain();
    var pan = ctx.createStereoPanner();
    sum.connect(comp); comp.connect(makeup); makeup.connect(pan); pan.connect(outp);
    var an = ctx.createAnalyser(); an.fftSize = 512; outp.connect(an);
    var wet = ctx.createGain(), dry = ctx.createGain(); dry.gain.value = 0;
    outp.connect(wet); wet.connect(destNode);
    srcNode.connect(dry); dry.connect(destNode);
    Object.assign(C.nodes, { front: front, back: back, outp: outp, filters: filters, conv: conv, revWet: revWet, dly: dly, fb: fb, echoWet: echoWet, phWet: phWet, dblWet: dblWet, comp: comp, makeup: makeup, pan: pan, wet: wet, dry: dry, an: an, inGain: inGain });
    C.irSize = 0; C.irTimer = null;
    C.apply = function () { applyParams(C); };
    C.dispose = function () { try { [front, back, outp, lfo, lfo2].forEach(function (n) { try { n.disconnect(); } catch (e) {} }); try { lfo.stop(); lfo2.stop(); } catch (e) {} } catch (e) {} };
    applyParams(C);
    return C;
  }

  function applyParams(C) {
    var n = C.nodes, ctx = C.ctx, t = ctx.currentTime, T = 0.02;
    var sm = function (ap, v) { try { ap.setTargetAtTime(v, t, T); } catch (e) { ap.value = v; } };
    var totalDb = P.pre * 0.3 + P.g1 * 0.3 + P.g2 * 0.3 + P.g3 * 0.3 + P.g4 * 0.3 + P.omega * 0.4;
    n.front.port.postMessage({ gate: P.gate > 0 ? dbLin(-90 + P.gate * 0.6) : 0, gain: dbLin(totalDb), pitch: Math.pow(2, P.pitch / 12), ringMix: P.ring / 100, ringFreq: P.ringFreq, mute: flags.mute ? 1 : 0 });
    n.back.port.postMessage({ sat: P.sat / 100, fold: P.fold / 100, asym: P.asym / 100, blood: P.blood / 100, crush: P.crush / 100, noise: P.noise / 100, fat: P.fat / 100, nuke: P.nuke / 100, breath: P.breath / 100 });
    n.outp.port.postMessage({ width: P.width / 100, mono: P.mono ? 1 : 0, invert: P.invert ? 1 : 0, master: P.master / 100, brick: P.brick / 100, soft: P.limiter ? 1 : 0, mute: flags.mute ? 1 : 0 });
    var F = n.filters;
    if (P.bassKill > 0) { F.hpf.frequency.setTargetAtTime(20 * Math.pow(20, P.bassKill / 100), t, T); } else { F.hpf.frequency.setTargetAtTime(10, t, T); }
    sm(F.bass.gain, P.bass); sm(F.mid.gain, P.mid); sm(F.treble.gain, P.treble);
    sm(F.sharp.gain, P.sharp * 0.12); sm(F.scream.gain, P.scream * 0.15); sm(F.laser.gain, P.laser * 0.15); sm(F.hiss.gain, P.hiss * 0.12);
    sm(F.air.gain, P.air * 0.1); sm(F.quake.gain, P.quake * 0.18); sm(F.sub.gain, P.sub * 0.15); sm(F.tremor.gain, P.tremor * 0.15); sm(F.doom.gain, P.doom * 0.18);
    sm(n.revWet.gain, P.revMix / 100); sm(n.echoWet.gain, P.echoMix / 100); sm(n.fb.gain, P.echoFb / 100); sm(n.dly.delayTime, P.echoTime / 1000);
    sm(n.phWet.gain, P.phaser / 100 * 0.8); sm(n.dblWet.gain, P.dbl / 100 * 0.7);
    sm(n.comp.threshold, -P.comp * 0.4); sm(n.comp.ratio, 1 + P.comp * 0.11); sm(n.makeup.gain, 1 + P.comp / 100 * 2);
    sm(n.pan.pan, P.pan / 100);
    sm(n.wet.gain, flags.bypass ? 0 : 1); sm(n.dry.gain, flags.bypass ? 1 : 0);
    var size = P.revSize / 10;
    if (C.irSize !== size && P.revMix > 0) {
      clearTimeout(C.irTimer);
      C.irTimer = setTimeout(function () { try { n.conv.buffer = makeIR(ctx, size); C.irSize = size; } catch (e) {} }, 120);
    }
  }

  /* ------------------------------------------------------------------ *
   *  getUserMedia hook
   * ------------------------------------------------------------------ */
  var chains = [];
  var sharedCtx = null;
  function getCtx() {
    if (!sharedCtx || sharedCtx.state === 'closed') {
      var AC = window.AudioContext || window.webkitAudioContext;
      try { sharedCtx = new AC({ latencyHint: 'interactive', sampleRate: 48000 }); } catch (e) { sharedCtx = new AC({ latencyHint: 'interactive' }); }
    }
    if (sharedCtx.state === 'suspended') sharedCtx.resume().catch(function () {});
    return sharedCtx;
  }
  ['pointerdown', 'touchend', 'keydown'].forEach(function (ev) {
    document.addEventListener(ev, function () { if (sharedCtx && sharedCtx.state === 'suspended') sharedCtx.resume().catch(function () {}); }, true);
  });

  async function processStream(stream) {
    var tracks = stream.getAudioTracks();
    if (!tracks.length) return stream;
    var ctx = getCtx();
    var src = ctx.createMediaStreamSource(new MediaStream(tracks));
    var dest = ctx.createMediaStreamDestination(); dest.channelCount = 2;
    var C = await buildChain(ctx, src, dest);
    chains.push(C);
    var out = new MediaStream(dest.stream.getAudioTracks().concat(stream.getVideoTracks()));
    var ot = out.getAudioTracks()[0];
    if (ot) {
      var stop = ot.stop.bind(ot);
      ot.stop = function () { stop(); tracks.forEach(function (t) { t.stop(); }); try { src.disconnect(); } catch (e) {} C.dispose(); var i = chains.indexOf(C); if (i >= 0) chains.splice(i, 1); };
      tracks.forEach(function (t) { t.addEventListener('ended', function () { try { ot.dispatchEvent(new Event('ended')); } catch (e) {} }); });
    }
    return out;
  }

  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    var md = navigator.mediaDevices, orig = md.getUserMedia.bind(md);
    md.getUserMedia = async function (c) {
      var cons = c;
      if (c && c.audio) {
        var a = c.audio === true ? {} : Object.assign({}, c.audio);
        if (a.autoGainControl === undefined) a.autoGainControl = false;
        if (a.noiseSuppression === undefined) a.noiseSuppression = false;
        cons = Object.assign({}, c, { audio: a });
      }
      var s = await orig(cons);
      if (!c || !c.audio) return s;
      try { return await processStream(s); } catch (e) { console.warn('[Akira] engine failed, using raw mic', e); return s; }
    };
  }

  /* ------------------------------------------------------------------ *
   *  Stereo Opus SDP patch (fail-safe)
   * ------------------------------------------------------------------ */
  function patchSdp(sdp) {
    try {
      if (!P.opus || typeof sdp !== 'string') return sdp;
      var lines = sdp.split('\r\n'), pts = [];
      lines.forEach(function (l) { var m = /^a=rtpmap:(\d+) opus\/48000\/2/i.exec(l); if (m) pts.push(m[1]); });
      if (!pts.length) return sdp;
      pts.forEach(function (pt) {
        var found = false;
        for (var i = 0; i < lines.length; i++) {
          if (lines[i].indexOf('a=fmtp:' + pt + ' ') === 0) {
            found = true;
            if (!/stereo=1/.test(lines[i])) lines[i] += ';stereo=1';
            if (!/sprop-stereo=1/.test(lines[i])) lines[i] += ';sprop-stereo=1';
          }
        }
        if (!found) {
          for (var j = 0; j < lines.length; j++) if (lines[j].indexOf('a=rtpmap:' + pt + ' ') === 0) { lines.splice(j + 1, 0, 'a=fmtp:' + pt + ' stereo=1;sprop-stereo=1'); break; }
        }
      });
      return lines.join('\r\n');
    } catch (e) { return sdp; }
  }
  if (window.RTCPeerConnection) {
    var RP = RTCPeerConnection.prototype;
    ['setLocalDescription', 'setRemoteDescription'].forEach(function (name) {
      var o = RP[name]; if (!o) return;
      RP[name] = function (d) {
        try { if (d && d.sdp) { d = { type: d.type, sdp: patchSdp(d.sdp) }; } } catch (e) {}
        return o.apply(this, arguments.length > 1 ? [d].concat([].slice.call(arguments, 1)) : [d]);
      };
    });
    ['createOffer', 'createAnswer'].forEach(function (name) {
      var o = RP[name]; if (!o) return;
      RP[name] = function () {
        return o.apply(this, arguments).then(function (d) { try { return { type: d.type, sdp: patchSdp(d.sdp) }; } catch (e) { return d; } });
      };
    });
  }

  /* ------------------------------------------------------------------ *
   *  Public API (used by the panel and tests)
   * ------------------------------------------------------------------ */
  function applyAll() { chains.forEach(function (c) { try { c.apply(); } catch (e) {} }); persist(); }
  function setParam(id, v) { var d = DEFMAP[id]; if (!d) return; P[id] = clamp(+v, d.min, d.max); applyAll(); }
  function applyPreset(name) {
    var f = PRESETS[name]; if (!f) return;
    DEFS.forEach(function (d) { P[d.id] = d.def; });
    var o = f(); for (var k in o) if (k in P) P[k] = o[k];
    applyAll(); if (window.__akiraRefresh) window.__akiraRefresh();
  }
  window.Akira = { P: P, DEFS: DEFS, flags: flags, chains: chains, setParam: setParam, applyPreset: applyPreset, buildChain: buildChain, applyAll: applyAll, patchSdp: patchSdp, TABS: TABS, PRESETS: PRESETS };

  /* ------------------------------------------------------------------ *
   *  PANEL
   * ------------------------------------------------------------------ */
  var CSS = String.raw`
@keyframes ak-edge{0%{background-position:0% 50%}100%{background-position:300% 50%}}
@keyframes ak-title{0%,100%{text-shadow:0 0 8px rgba(255,45,85,.9),0 0 20px rgba(255,45,85,.5)}50%{text-shadow:0 0 12px #ff2d55,0 0 32px rgba(255,45,85,.85),0 0 46px rgba(176,38,255,.55)}}
@keyframes ak-pulse{0%,100%{box-shadow:0 0 12px rgba(255,45,85,.6),0 0 28px rgba(176,38,255,.3)}50%{box-shadow:0 0 22px rgba(255,45,85,.95),0 0 44px rgba(176,38,255,.55)}}
#ak-root,#ak-root *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
#ak-root{--r:#ff2d55;--v:#b026ff;--c:#00f0ff;font-family:Inter,system-ui,-apple-system,"Segoe UI",sans-serif;color:#f8f2ff;user-select:none;-webkit-user-select:none}
#ak-bub{position:fixed;right:12px;bottom:84px;z-index:2147483646;padding:9px 16px;font:900 11px/1 inherit;letter-spacing:3px;color:#fff;border-radius:999px;cursor:pointer;
  background:linear-gradient(135deg,rgba(255,45,85,.3),rgba(176,38,255,.25)),#0a0610;border:1px solid rgba(255,45,85,.8);text-shadow:0 0 8px rgba(255,45,85,.9);animation:ak-pulse 2.4s ease-in-out infinite}
#ak-pan{position:fixed;top:48px;left:max(6px,calc(100vw - 316px));width:min(308px,calc(100vw - 12px));z-index:2147483647;display:none;overflow:hidden;border-radius:18px;
  background:radial-gradient(120% 40% at 50% 0%,rgba(255,45,85,.16),transparent 70%),radial-gradient(100% 40% at 50% 100%,rgba(176,38,255,.14),transparent 70%),rgba(8,5,14,.96);
  border:1px solid rgba(255,45,85,.6);box-shadow:0 0 0 1px rgba(176,38,255,.25),0 0 26px rgba(255,45,85,.5),0 0 64px rgba(176,38,255,.28),0 16px 40px rgba(0,0,0,.8);backdrop-filter:blur(14px)}
#ak-pan::before{content:"";position:absolute;left:0;right:0;top:0;height:2px;z-index:5;pointer-events:none;background:linear-gradient(90deg,var(--r),var(--v),var(--c),var(--v),var(--r));background-size:300% 100%;animation:ak-edge 4s linear infinite;box-shadow:0 0 12px var(--r)}
#ak-hd{display:flex;align-items:center;gap:8px;padding:10px 12px;cursor:move;touch-action:none;background:linear-gradient(135deg,rgba(255,45,85,.22),rgba(176,38,255,.1) 60%,rgba(10,6,18,.3));border-bottom:1px solid rgba(255,45,85,.4)}
#ak-ti{font-weight:900;font-size:15px;letter-spacing:3px;color:#fff;animation:ak-title 2.6s ease-in-out infinite}
#ak-ti span{color:var(--r)}
#ak-meter{flex:1;height:6px;border-radius:99px;background:rgba(255,255,255,.1);overflow:hidden;box-shadow:0 0 8px rgba(255,45,85,.25)}
#ak-meter i{display:block;height:100%;width:0%;background:linear-gradient(90deg,var(--c),var(--r));transition:width .08s linear;box-shadow:0 0 10px var(--r)}
#ak-x{width:26px;height:26px;border-radius:8px;border:1px solid rgba(255,45,85,.5);background:rgba(255,45,85,.08);color:#ffb3c1;font-size:13px;cursor:pointer}
#ak-tabs{display:flex;gap:4px;padding:7px 8px;overflow-x:auto;border-bottom:1px solid rgba(176,38,255,.3);background:rgba(10,6,18,.6);scrollbar-width:none;-webkit-overflow-scrolling:touch}
#ak-tabs::-webkit-scrollbar{display:none}
.ak-tab{flex:0 0 auto;padding:7px 11px;border-radius:9px;border:1px solid rgba(176,38,255,.35);background:rgba(255,255,255,.03);color:rgba(255,255,255,.55);font:800 9.5px inherit;letter-spacing:1.4px;cursor:pointer}
.ak-tab.on{color:#fff;border-color:var(--r);background:linear-gradient(135deg,rgba(255,45,85,.3),rgba(176,38,255,.22));box-shadow:0 0 12px rgba(255,45,85,.5);text-shadow:0 0 8px var(--r)}
#ak-body{max-height:min(46vh,380px);overflow-y:auto;overflow-x:hidden;padding:9px;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;touch-action:pan-y}
#ak-body::-webkit-scrollbar{width:4px}#ak-body::-webkit-scrollbar-thumb{background:linear-gradient(var(--r),var(--v));border-radius:3px}
.ak-row{padding:8px 10px 10px;margin-bottom:7px;border-radius:12px;border:1px solid rgba(176,38,255,.3);background:linear-gradient(160deg,rgba(255,255,255,.05),rgba(255,255,255,.012));box-shadow:inset 0 0 14px rgba(176,38,255,.07)}
.ak-l{display:flex;justify-content:space-between;align-items:center;font:800 9.5px inherit;letter-spacing:.6px;color:#e4d3f2;margin-bottom:7px}
.ak-l b{color:var(--c);font-weight:800;text-shadow:0 0 8px rgba(0,240,255,.7);font-variant-numeric:tabular-nums}
.ak-row.nuke .ak-l span{color:var(--r);text-shadow:0 0 8px var(--r)}
#ak-root input[type=range]{--p:0%;-webkit-appearance:none;appearance:none;width:100%;height:5px;border-radius:99px;outline:none;touch-action:pan-y;
  background:linear-gradient(90deg,var(--r),var(--v)) 0 0/var(--p) 100% no-repeat,rgba(255,255,255,.12);box-shadow:0 0 8px rgba(255,45,85,.3)}
#ak-root input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;border-radius:50%;border:2px solid #fff;background:radial-gradient(circle,#fff 0 30%,var(--r) 33%);box-shadow:0 0 12px var(--r),0 0 26px rgba(255,45,85,.6)}
.ak-tg{display:flex;justify-content:space-between;align-items:center;font:800 9.5px inherit;letter-spacing:.6px;color:#e4d3f2}
.ak-sw{width:40px;height:20px;border-radius:99px;border:1px solid rgba(176,38,255,.5);background:rgba(255,255,255,.08);position:relative;cursor:pointer;flex:0 0 auto}
.ak-sw::after{content:"";position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;background:#6b5a7c;transition:.2s}
.ak-sw.on{background:rgba(255,45,85,.35);border-color:var(--r);box-shadow:0 0 14px rgba(255,45,85,.7)}
.ak-sw.on::after{left:22px;background:#fff;box-shadow:0 0 8px #fff}
.ak-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}
.ak-pb{padding:12px 6px;border-radius:11px;border:1px solid rgba(176,38,255,.45);background:linear-gradient(135deg,rgba(255,45,85,.14),rgba(176,38,255,.12));color:#fff;font:800 9.5px inherit;letter-spacing:1px;cursor:pointer;text-shadow:0 0 8px rgba(255,45,85,.7)}
.ak-pb:active{background:var(--r);box-shadow:0 0 18px var(--r)}
.ak-sec{color:var(--r);font:900 9.5px inherit;letter-spacing:2px;margin:4px 2px 7px;text-shadow:0 0 8px rgba(255,45,85,.8)}
#ak-ft{display:flex;gap:6px;padding:8px;border-top:1px solid rgba(255,45,85,.35);background:rgba(10,6,18,.78)}
#ak-ft button{flex:1;min-height:38px;padding:6px 2px;border-radius:10px;border:1px solid rgba(255,45,85,.7);background:linear-gradient(135deg,rgba(255,45,85,.25),rgba(176,38,255,.22));color:#fff;font:900 9px inherit;letter-spacing:.9px;text-shadow:0 0 8px rgba(255,45,85,.9);cursor:pointer;touch-action:manipulation}
#ak-ft button.sc{flex:0 0 40px;font-size:13px}
#ak-ft button.on{background:var(--r);box-shadow:0 0 16px var(--r)}
#ak-ft button:active{background:var(--r)}
`;

  var ui = {};
  var curTab = 'GAIN';

  function el(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  function paint(inp) { var mn = +inp.min, mx = +inp.max; inp.style.setProperty('--p', ((inp.value - mn) / (mx - mn) * 100) + '%'); }

  function renderBody() {
    var body = ui.body; body.innerHTML = '';
    body.scrollTop = 0;
    if (curTab === 'PRESETS') { renderPresets(body); return; }
    DEFS.filter(function (d) { return d.tab === curTab; }).forEach(function (d) {
      var row = el('div', 'ak-row' + (d.id === 'nuke' ? ' nuke' : ''));
      if (d.disp === 'toggle') {
        var tg = el('div', 'ak-tg'); tg.appendChild(el('span', '', d.label));
        var sw = el('div', 'ak-sw' + (P[d.id] ? ' on' : '')); sw.setAttribute('role', 'switch');
        sw.addEventListener('click', function () { setParam(d.id, P[d.id] ? 0 : 1); sw.classList.toggle('on', !!P[d.id]); });
        tg.appendChild(sw); row.appendChild(tg);
      } else {
        var l = el('div', 'ak-l'); l.appendChild(el('span', '', d.label)); var vb = el('b', '', d.disp(P[d.id])); l.appendChild(vb); row.appendChild(l);
        var inp = document.createElement('input'); inp.type = 'range'; inp.min = d.min; inp.max = d.max; inp.step = (d.max - d.min) > 60 ? 1 : 0.5; inp.value = P[d.id]; paint(inp);
        inp.addEventListener('input', function () { setParam(d.id, inp.value); vb.textContent = d.disp(P[d.id]); paint(inp); });
        row.appendChild(inp);
        guard(inp);
      }
      body.appendChild(row);
    });
  }

  function renderPresets(body) {
    body.appendChild(el('div', 'ak-sec', 'AKIRA PRESETS'));
    var g = el('div', 'ak-grid');
    Object.keys(PRESETS).forEach(function (n) { var b = el('button', 'ak-pb', n); b.addEventListener('click', function () { applyPreset(n); renderBody(); }); g.appendChild(b); });
    body.appendChild(g);
    body.appendChild(el('div', 'ak-sec', 'MY SLOTS (tap SAVE, then LOAD later)'));
    var g2 = el('div', 'ak-grid');
    [1, 2, 3].forEach(function (i) {
      var s = el('button', 'ak-pb', 'SAVE SLOT ' + i), l = el('button', 'ak-pb', 'LOAD SLOT ' + i);
      s.addEventListener('click', function () { try { localStorage.setItem('akira:slot' + i, JSON.stringify(P)); s.textContent = 'SAVED ✓'; setTimeout(function () { s.textContent = 'SAVE SLOT ' + i; }, 900); } catch (e) {} });
      l.addEventListener('click', function () { try { var o = JSON.parse(localStorage.getItem('akira:slot' + i) || 'null'); if (o) { for (var k in o) if (k in P) P[k] = o[k]; applyAll(); renderBody(); } else { l.textContent = 'EMPTY'; setTimeout(function () { l.textContent = 'LOAD SLOT ' + i; }, 900); } } catch (e) {} });
      g2.appendChild(s); g2.appendChild(l);
    });
    body.appendChild(g2);
  }

  // A vertical swipe that starts on a slider scrolls the panel; it must not change the gain.
  var gs = null;
  function guard(inp) {
    inp.addEventListener('touchstart', function (e) { if (e.touches.length === 1) gs = { el: inp, val: inp.value, x: e.touches[0].clientX, y: e.touches[0].clientY, v: false }; else gs = null; }, { passive: true });
  }
  document.addEventListener('touchmove', function (e) {
    if (!gs || !e.touches.length) return;
    var dx = Math.abs(e.touches[0].clientX - gs.x), dy = Math.abs(e.touches[0].clientY - gs.y);
    if (!gs.v && dy > 10 && dy > dx * 1.5) gs.v = true;
  }, { capture: true, passive: true });
  function endGuard() {
    if (!gs) return; var s = gs; gs = null; if (!s.v) return;
    var restore = function () { if (s.el.value !== s.val) { s.el.value = s.val; s.el.dispatchEvent(new Event('input', { bubbles: true })); } };
    restore(); setTimeout(restore, 30); setTimeout(restore, 120);
  }
  document.addEventListener('touchend', endGuard, { capture: true, passive: true });
  document.addEventListener('touchcancel', endGuard, { capture: true, passive: true });

  function buildUI() {
    if (document.getElementById('ak-root')) return;
    var st = document.createElement('style'); st.id = 'ak-css'; st.textContent = CSS;
    var root = el('div'); root.id = 'ak-root';
    var bub = el('div', '', 'AKIRA'); bub.id = 'ak-bub';
    var pan = el('div'); pan.id = 'ak-pan';
    var hd = el('div'); hd.id = 'ak-hd';
    var ti = el('div'); ti.id = 'ak-ti'; ti.innerHTML = 'AKIRA<span> V1</span>';
    var meter = el('div'); meter.id = 'ak-meter'; meter.appendChild(document.createElement('i'));
    var x = el('button', '', '✕'); x.id = 'ak-x';
    hd.appendChild(ti); hd.appendChild(meter); hd.appendChild(x);
    var tabs = el('div'); tabs.id = 'ak-tabs';
    TABS.forEach(function (t) {
      var b = el('button', 'ak-tab' + (t === curTab ? ' on' : ''), t);
      b.addEventListener('click', function () { curTab = t; [].forEach.call(tabs.children, function (c) { c.classList.toggle('on', c === b); }); renderBody(); });
      tabs.appendChild(b);
    });
    var body = el('div'); body.id = 'ak-body';
    var ft = el('div'); ft.id = 'ak-ft';
    var up = el('button', 'sc', '▲'), dn = el('button', 'sc', '▼');
    var byp = el('button', '', 'BYPASS'), mut = el('button', '', 'MUTE'), rst = el('button', '', 'RESET');
    up.addEventListener('click', function () { body.scrollBy({ top: -Math.round(body.clientHeight * 0.8), behavior: 'smooth' }); });
    dn.addEventListener('click', function () { body.scrollBy({ top: Math.round(body.clientHeight * 0.8), behavior: 'smooth' }); });
    byp.addEventListener('click', function () { flags.bypass = !flags.bypass; byp.classList.toggle('on', flags.bypass); applyAll(); });
    mut.addEventListener('click', function () { flags.mute = !flags.mute; mut.classList.toggle('on', flags.mute); applyAll(); });
    rst.addEventListener('click', function () { applyPreset('DEFAULT'); renderBody(); });
    [up, byp, mut, rst, dn].forEach(function (b) { ft.appendChild(b); });
    pan.appendChild(hd); pan.appendChild(tabs); pan.appendChild(body); pan.appendChild(ft);
    root.appendChild(bub); root.appendChild(pan);
    (document.head || document.documentElement).appendChild(st);
    document.documentElement.appendChild(root);
    ui = { root: root, bub: bub, pan: pan, body: body, meter: meter.firstChild };
    var open = function (o) { pan.style.display = o ? 'block' : 'none'; bub.style.display = o ? 'none' : 'block'; };
    bub.addEventListener('click', function () { open(true); });
    x.addEventListener('click', function () { open(false); });
    // drag by header
    var drag = null;
    hd.addEventListener('touchstart', function (e) { var t = e.touches[0], r = pan.getBoundingClientRect(); drag = { dx: t.clientX - r.left, dy: t.clientY - r.top }; }, { passive: true });
    hd.addEventListener('touchmove', function (e) { if (!drag) return; var t = e.touches[0]; pan.style.left = clamp(t.clientX - drag.dx, 0, window.innerWidth - 60) + 'px'; pan.style.top = clamp(t.clientY - drag.dy, 0, window.innerHeight - 60) + 'px'; }, { passive: true });
    hd.addEventListener('touchend', function () { drag = null; }, { passive: true });
    renderBody();
    window.__akiraRefresh = function () { renderBody(); };
    // level meter
    var buf = new Uint8Array(256);
    setInterval(function () {
      if (pan.style.display !== 'block') return;
      var c = chains[0]; if (!c) { ui.meter.style.width = '0%'; return; }
      try { c.nodes.an.getByteTimeDomainData(buf); var pk = 0; for (var i = 0; i < buf.length; i++) { var v = Math.abs(buf[i] - 128) / 128; if (v > pk) pk = v; } ui.meter.style.width = Math.round(pk * 100) + '%'; } catch (e) {}
    }, 90);
  }

  function boot() {
    buildUI();
    setInterval(function () { if (!document.getElementById('ak-root')) { ui = {}; buildUI(); } }, 2000);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
