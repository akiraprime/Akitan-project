/* UNIFIED SHELL - one crimson panel that hosts BOTH engines (Akira + BlakeCord) with an animated portrait
   (blinking, eye movement, breathing, follows your finger), mode switch, and side up/down scroll buttons.
   It only re-parents the two engines' own UI; their audio code is not touched. */
(function () {
  'use strict';
  if (window.__UNI_SHELL__) return;
  window.__UNI_SHELL__ = true;

  var PORT = window.__PORTRAIT_URL__ || '';
  var IW = 736, IH = 938;

  /* ------------------------------------------------------------------ *
   *  ANIMATED PORTRAIT
   * ------------------------------------------------------------------ */
  var img = new Image(), imgOK = false;
  var lidCol = ['rgb(214,120,150)', 'rgb(214,120,150)'];
  // eye ellipses in image pixel space (centre, radii, tilt)
  var EYES = [
    { x: 381, y: 164, rx: 23, ry: 10.5, rot: 0.30 },
    { x: 473, y: 187, rx: 23, ry: 10.5, rot: 0.34 }
  ];
  img.onload = function () {
    imgOK = true;
    try { // sample skin just under each eye for the eyelid colour
      var c = document.createElement('canvas'); c.width = IW; c.height = IH;
      var g = c.getContext('2d'); g.drawImage(img, 0, 0);
      EYES.forEach(function (e, i) {
        var d = g.getImageData(Math.round(e.x - 8), Math.round(e.y + 22), 16, 8).data, r = 0, gg = 0, b = 0, n = d.length / 4;
        for (var k = 0; k < d.length; k += 4) { r += d[k]; gg += d[k + 1]; b += d[k + 2]; }
        r = r / n; gg = gg / n; b = b / n;
        lidCol[i] = 'rgb(' + Math.min(255, Math.round(r * 1.08)) + ',' + Math.min(255, Math.round(gg * 1.1)) + ',' + Math.min(255, Math.round(b * 1.08)) + ')';
      });
    } catch (e) {}
  };
  img.src = PORT;

  var A = { px: 0, py: 0, tx: 0, ty: 0, gx: 0, gy: 0, gtx: 0, gty: 0, blink: 0, nodT: -1, nextBlink: 1.6, bStart: -1, dbl: false, nextSac: 0.8, last: 0 };
  var list = [];

  function onPointer(e) {
    var t = e.touches ? e.touches[0] : e; if (!t) return;
    A.tx = (t.clientX / window.innerWidth - 0.5) * 2;
    A.ty = (t.clientY / window.innerHeight - 0.5) * 2;
  }
  ['pointermove', 'touchmove', 'touchstart'].forEach(function (ev) { document.addEventListener(ev, onPointer, { passive: true, capture: true }); });

  function blinkAmount(t) {
    if (A.bStart < 0) {
      if (t >= A.nextBlink) { A.bStart = t; }
      return 0;
    }
    var d = (t - A.bStart) / 0.17;               // 170 ms down, 170 ms up
    if (d >= 2) {
      A.bStart = -1;
      if (!A.dbl && Math.random() < 0.22) { A.dbl = true; A.nextBlink = t + 0.12; }
      else { A.dbl = false; A.nextBlink = t + 2.2 + Math.random() * 3.2; }
      return 0;
    }
    return d < 1 ? d * d * (3 - 2 * d) : (2 - d) * (2 - d) * (3 - 2 * (2 - d));
  }

  function drawEyes(ctx, base, close, gx, gy) {
    EYES.forEach(function (e, i) {
      // 1) iris micro movement: re-draw the eye patch a hair off-centre inside a small ellipse
      if (gx || gy) {
        ctx.save();
        ctx.translate(e.x, e.y); ctx.rotate(e.rot);
        ctx.beginPath(); ctx.ellipse(0, 0, e.rx * 0.5, e.ry * 0.92, 0, 0, 6.2832); ctx.clip();
        ctx.setTransform(base[0], base[1], base[2], base[3], base[4], base[5]);
        ctx.drawImage(img, e.x - 30, e.y - 18, 60, 36, e.x - 30 + gx, e.y - 18 + gy, 60, 36);
        ctx.restore();
      }
      // 2) eyelid
      if (close > 0.02) {
        var top = -e.ry * 1.55, edge = top + close * e.ry * 3.1;
        ctx.save();
        ctx.translate(e.x, e.y); ctx.rotate(e.rot);
        ctx.beginPath(); ctx.rect(-e.rx * 1.4, -e.ry * 3, e.rx * 2.8, edge + e.ry * 3); ctx.clip();
        ctx.save();
        ctx.scale(1, (e.ry * 1.55) / (e.rx * 1.12));
        var gr = ctx.createRadialGradient(0, 0, e.rx * 0.2, 0, 0, e.rx * 1.18);
        var c0 = lidCol[i];
        gr.addColorStop(0, c0); gr.addColorStop(0.72, c0); gr.addColorStop(1, c0.replace('rgb(', 'rgba(').replace(')', ',0)'));
        ctx.fillStyle = gr;
        ctx.fillRect(-e.rx * 2, -e.rx * 2.4, e.rx * 4, e.rx * 4.8);
        ctx.restore();
        ctx.restore();
        // lash line along the lid edge
        ctx.save();
        ctx.translate(e.x, e.y); ctx.rotate(e.rot);
        ctx.lineCap = 'round';
        ctx.strokeStyle = 'rgba(28,6,20,' + Math.min(0.92, close * 2.2).toFixed(2) + ')';
        ctx.lineWidth = 1.7;
        ctx.beginPath();
        ctx.moveTo(-e.rx * 1.02, edge - e.ry * 0.1 * (1 - close));
        ctx.quadraticCurveTo(0, edge + e.ry * (0.55 - 0.25 * close), e.rx * 1.02, edge - e.ry * 0.1 * (1 - close));
        ctx.stroke();
        ctx.restore();
      }
    });
  }

  function render(p, t) {
    var cv = p.cv, w = cv.clientWidth, h = cv.clientHeight;
    if (!w || !h) return false;
    var dpr = Math.min(window.devicePixelRatio || 1, p.maxDpr || 2);
    var cw = Math.round(w * dpr), ch = Math.round(h * dpr);
    if (cv.width !== cw || cv.height !== ch) { cv.width = cw; cv.height = ch; }
    var ctx = cv.getContext('2d');
    var vw = p.vw, vh = vw * ch / cw;
    if (vh > IH) { vh = IH; vw = vh * cw / ch; }          // cover: never show past the image
    if (vw > IW) { vw = IW; vh = vw * ch / cw; }
    var br = 1 + 0.006 * Math.sin(t * 1.3);                           // breathing
    var zoom = br * (p.zoom || 1);
    vw /= zoom; vh /= zoom;
    var fx = p.fx + A.px * 5 * (p.par == null ? 1 : p.par), fy = p.fy + A.py * 3.5 * (p.par == null ? 1 : p.par) + Math.sin(t * 1.3) * 1.2 + (A.nodT >= 0 && t - A.nodT < 0.55 ? Math.sin((t - A.nodT) / 0.55 * Math.PI) * 6 : 0);
    var x0 = Math.max(0, Math.min(IW - vw, fx - vw / 2)), y0 = Math.max(0, Math.min(IH - vh, fy - vh / 2));
    var s = cw / vw;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, cw, ch);
    ctx.imageSmoothingQuality = 'high';
    ctx.setTransform(s, 0, 0, s, -x0 * s, -y0 * s);
    ctx.drawImage(img, 0, 0);
    if (p.eyes !== false) drawEyes(ctx, [s, 0, 0, s, -x0 * s, -y0 * s], A.blink, A.gx, A.gy);
    return true;
  }

  function tick(ms) {
    requestAnimationFrame(tick);
    var t = ms / 1000;
    if (t - A.last < 0.033) return;                                     // ~30 fps
    var dt = Math.min(0.1, t - A.last); A.last = t;
    if (!imgOK || document.hidden) return;
    // smooth pointer follow + eye saccades that settle back on the viewer
    A.px += (A.tx - A.px) * Math.min(1, dt * 3); A.py += (A.ty - A.py) * Math.min(1, dt * 3);
    if (t > A.nextSac) { A.gtx = (Math.random() - 0.5) * 1.1; A.gty = (Math.random() - 0.5) * 0.7; A.nextSac = t + 0.6 + Math.random() * 2.2; }
    A.gx += ((A.gtx + A.px * 0.9) - A.gx) * Math.min(1, dt * 10); A.gy += ((A.gty + A.py * 0.5) - A.gy) * Math.min(1, dt * 10);
    A.blink = blinkAmount(t);
    for (var i = list.length - 1; i >= 0; i--) {
      var p = list[i];
      if (!p.cv.isConnected) { list.splice(i, 1); continue; }
      if (p.cv.offsetParent === null && getComputedStyle(p.cv).position !== 'fixed') continue;
      render(p, t);
    }
  }
  requestAnimationFrame(tick);

  function addPortrait(cv, o) { var p = { cv: cv }; for (var k in o) p[k] = o[k]; list.push(p); return p; }

  /* ------------------------------------------------------------------ *
   *  STYLE
   * ------------------------------------------------------------------ */
  var CSS = [
    '@keyframes uni-edge{0%{background-position:0% 50%}100%{background-position:300% 50%}}',
    '@keyframes uni-glow{0%,100%{box-shadow:0 0 14px rgba(255,45,100,.7),0 0 34px rgba(176,38,255,.35)}50%{box-shadow:0 0 24px rgba(255,45,100,1),0 0 56px rgba(176,38,255,.6)}}',
    '@keyframes uni-title{0%,100%{text-shadow:0 0 8px rgba(255,45,100,.9),0 0 20px rgba(255,45,100,.5)}50%{text-shadow:0 0 14px #ff2d64,0 0 34px rgba(255,45,100,.9),0 0 48px rgba(176,38,255,.6)}}',
    '@keyframes uni-scan{0%{transform:translateY(-100%)}100%{transform:translateY(100%)}}',
    '#uni-root,#uni-root *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}',
    '#uni-root{position:fixed;inset:0;pointer-events:none;z-index:2147483640;font-family:Inter,system-ui,-apple-system,"Segoe UI",sans-serif;--r:#ff2d64;--v:#b026ff;--c:#ff9ac1}',
    '#uni-root svg{display:inline-block;width:1em;height:1em;vertical-align:-0.125em}',
    '#uni-launcher{position:fixed;right:12px;bottom:84px;width:68px;height:68px;border-radius:50%;pointer-events:auto;overflow:hidden;border:2px solid #ff2d64;background:#12040c;animation:uni-glow 2.4s ease-in-out infinite;touch-action:none}',
    '#uni-launcher canvas{width:100%;height:100%;display:block}',
    '#uni-panel{position:fixed;right:6px;bottom:6px;width:min(430px,calc(100vw - 12px));height:min(calc(100dvh - 12px),780px);display:none;flex-direction:column;pointer-events:auto;overflow:hidden;border-radius:20px;',
    '  background:radial-gradient(120% 35% at 50% 0%,rgba(255,45,100,.2),transparent 70%),radial-gradient(100% 40% at 50% 100%,rgba(176,38,255,.18),transparent 70%),rgba(12,4,12,.97);',
    '  border:1px solid rgba(255,45,100,.65);box-shadow:0 0 0 1px rgba(176,38,255,.3),0 0 30px rgba(255,45,100,.5),0 0 70px rgba(176,38,255,.3),0 18px 44px rgba(0,0,0,.85)}',
    '#uni-panel::before{content:"";position:absolute;left:0;right:0;top:0;height:2px;z-index:30;pointer-events:none;background:linear-gradient(90deg,var(--r),var(--v),var(--c),var(--v),var(--r));background-size:300% 100%;animation:uni-edge 4s linear infinite;box-shadow:0 0 12px var(--r)}',
    '#uni-banner{position:relative;flex:0 0 auto;height:clamp(96px,17dvh,150px);overflow:hidden;border-bottom:1px solid rgba(255,45,100,.5);touch-action:none}',
    '#uni-banner canvas{position:absolute;inset:0;width:100%;height:100%;display:block}',
    '#uni-banner::after{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(180deg,rgba(10,2,10,.15) 0%,rgba(10,2,10,0) 40%,rgba(10,2,10,.88) 100%),radial-gradient(120% 120% at 50% 40%,transparent 55%,rgba(60,0,40,.55) 100%)}',
    '#uni-scan{position:absolute;inset:0;pointer-events:none;overflow:hidden;z-index:2;opacity:.35}',
    '#uni-scan::before{content:"";position:absolute;left:0;right:0;height:40%;background:linear-gradient(180deg,transparent,rgba(255,120,170,.22),transparent);animation:uni-scan 4.5s linear infinite}',
    '#uni-title{position:absolute;left:12px;bottom:8px;z-index:3;color:#fff;font-weight:900;font-size:17px;letter-spacing:4px;animation:uni-title 2.6s ease-in-out infinite}',
    '#uni-title small{display:block;font-size:8px;font-weight:700;letter-spacing:3px;color:var(--c);opacity:.9;margin-top:3px;animation:none;text-shadow:none}',
    '#uni-x{position:absolute;right:10px;top:10px;z-index:4;width:30px;height:30px;border-radius:9px;border:1px solid rgba(255,45,100,.7);background:rgba(20,2,12,.6);color:#ffc2d4;font-size:14px;cursor:pointer;backdrop-filter:blur(6px)}',
    '#uni-modes{display:flex;gap:6px;padding:7px 8px;background:rgba(14,4,14,.85);border-bottom:1px solid rgba(176,38,255,.3);flex:0 0 auto}',
    '#uni-modes button{flex:1;padding:9px 4px;border-radius:11px;border:1px solid rgba(176,38,255,.45);background:rgba(255,255,255,.03);color:rgba(255,255,255,.6);font:900 11px inherit;letter-spacing:2.5px;cursor:pointer}',
    '#uni-modes button.on{color:#fff;border-color:var(--r);background:linear-gradient(135deg,rgba(255,45,100,.38),rgba(176,38,255,.28));box-shadow:0 0 14px rgba(255,45,100,.55);text-shadow:0 0 8px var(--r)}',
    '#uni-stage{position:relative;flex:1 1 auto;min-height:0;overflow:hidden}',
    '#uni-stage::before{content:"";position:absolute;inset:0;pointer-events:none;background:var(--pimg) center 20%/cover no-repeat;opacity:.07;filter:saturate(1.3)}',
    '#uni-view{position:absolute;top:0;bottom:0;left:30px;right:30px}',
    '.uni-side{position:absolute;top:0;bottom:0;width:30px;display:flex;flex-direction:column;justify-content:center;gap:12px;align-items:center;z-index:20}',
    '.uni-side.l{left:0}.uni-side.r{right:0}',
    '.uni-arr{width:26px;height:56px;border-radius:13px;border:1px solid rgba(255,45,100,.75);background:linear-gradient(180deg,rgba(255,45,100,.3),rgba(176,38,255,.25));color:#fff;font-size:15px;line-height:1;display:flex;align-items:center;justify-content:center;touch-action:none;user-select:none;-webkit-user-select:none;box-shadow:0 0 12px rgba(255,45,100,.45);text-shadow:0 0 8px var(--r)}',
    '.uni-arr:active,.uni-arr.hold{background:var(--r);box-shadow:0 0 20px var(--r)}',
    /* hosted engines: fill the stage */
    '#uni-view #ak-root,#uni-view #bc-root{position:absolute!important;inset:0!important;width:auto!important;height:auto!important;pointer-events:none!important;z-index:1!important}',
    '#uni-view #ak-bub,#uni-view #bc-launcher,#uni-view #ak-hd,#uni-view .bc-hdr,#uni-view .bc-gif-bg,#uni-view .bc-gif-bg-overlay,#uni-view #ak-ft button.sc{display:none!important}',
    '#uni-view #ak-pan,#uni-view #bc-panel{position:absolute!important;inset:0!important;top:0!important;left:0!important;right:0!important;bottom:0!important;width:auto!important;height:auto!important;max-height:none!important;margin:0!important;border-radius:0!important;border:0!important;box-shadow:none!important;background:transparent!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;opacity:1!important;transform:none!important;transition:none!important;pointer-events:auto!important;display:none!important;flex-direction:column}',
    '#uni-view #ak-pan::before{display:none!important}',
    '#uni-view #ak-pan.uni-on,#uni-view #bc-panel.uni-on{display:flex!important}',
    '#uni-view #ak-body{flex:1 1 auto!important;max-height:none!important;min-height:0}',
    '#uni-view #ak-tabs,#uni-view .bc-tabs{flex:0 0 auto}',
    '#uni-view #ak-ft{flex:0 0 auto}',
    '#uni-view .bc-body{min-height:0}',
    '@keyframes uni-glitch{0%,88%,100%{transform:none}90%{transform:translate(-3px,1px);text-shadow:3px 0 #00e5ff,-3px 0 #ff2d64}94%{transform:translate(3px,-1px);text-shadow:-3px 0 #00e5ff,3px 0 #ff2d64}97%{transform:none}}',
    '@keyframes uni-marq{from{transform:translateX(0)}to{transform:translateX(-50%)}}',
    '@keyframes uni-spin{to{transform:rotate(360deg)}}',
    '#uni-launcher::after{content:"";position:absolute;inset:0;border-radius:50%;pointer-events:none;background:conic-gradient(from 0deg,transparent 0 25%,#ff2d64 45%,transparent 60%,#b026ff 80%,transparent);animation:uni-spin 2s linear infinite;-webkit-mask:radial-gradient(farthest-side,transparent calc(100% - 4px),#000 calc(100% - 3px));mask:radial-gradient(farthest-side,transparent calc(100% - 4px),#000 calc(100% - 3px))}',
    '#uni-banner::before{content:"";position:absolute;inset:6px;z-index:3;pointer-events:none;background:linear-gradient(#ff2d64,#ff2d64) top left/16px 2px no-repeat,linear-gradient(#ff2d64,#ff2d64) top left/2px 16px no-repeat,linear-gradient(#ff2d64,#ff2d64) top right/16px 2px no-repeat,linear-gradient(#ff2d64,#ff2d64) top right/2px 16px no-repeat,linear-gradient(#b026ff,#b026ff) bottom left/16px 2px no-repeat,linear-gradient(#b026ff,#b026ff) bottom left/2px 16px no-repeat,linear-gradient(#b026ff,#b026ff) bottom right/16px 2px no-repeat,linear-gradient(#b026ff,#b026ff) bottom right/2px 16px no-repeat;filter:drop-shadow(0 0 4px #ff2d64)}',
    '#uni-banner.talk{box-shadow:inset 0 0 34px rgba(255,45,100,.65)}',
    '#uni-embers{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:2}',
    '#uni-title{font-size:21px;letter-spacing:5px;animation:uni-title 2.6s ease-in-out infinite,uni-glitch 3.4s steps(1) infinite}',
    '#uni-cap{position:absolute;right:12px;bottom:10px;z-index:5;max-width:55%;padding:6px 13px;border-radius:99px;background:rgba(20,2,12,.72);border:1px solid #ff2d64;color:#fff;font:800 12px inherit;letter-spacing:1.5px;opacity:0;transform:translateY(6px) scale(.95);transition:all .25s;pointer-events:none;text-shadow:0 0 8px #ff2d64;box-shadow:0 0 14px rgba(255,45,100,.6)}',
    '#uni-cap.show{opacity:1;transform:none}',
    '#uni-ticker{flex:0 0 auto;overflow:hidden;white-space:nowrap;border-bottom:1px solid rgba(255,45,100,.35);background:linear-gradient(90deg,rgba(255,45,100,.2),rgba(176,38,255,.2),rgba(255,45,100,.2));font:900 9px inherit;letter-spacing:3px;color:#ffd1e0;padding:5px 0;text-shadow:0 0 8px #ff2d64}',
    '#uni-ticker div{display:inline-block;animation:uni-marq 16s linear infinite}',
    '#uni-viz{flex:0 0 auto;display:block;width:100%;height:28px;background:rgba(10,2,10,.75);border-bottom:1px solid rgba(176,38,255,.3)}',
    'body.uni-noscroll{overscroll-behavior:none}'
  ].join('\n');


  /* ------------------------------------------------------------------ *
   *  FX: audio-reactive spectrum + floating embers
   * ------------------------------------------------------------------ */
  var fxRaf = 0, bars = [], lastDb = -90, embers = [];
  for (var bi = 0; bi < 36; bi++) bars.push(0);
  window.addEventListener('blakecord:levels', function (e) { try { lastDb = e.detail.db; } catch (x) {} });

  function fx(ts) {
    if (!panel || panel.style.display !== 'flex') { fxRaf = 0; return; }
    fxRaf = requestAnimationFrame(fx);
    // spectrum strip
    var cv = vizCv, w = cv.clientWidth, h = cv.clientHeight;
    if (w && h) {
      var dpr = Math.min(2, window.devicePixelRatio || 1);
      if (cv.width !== Math.round(w * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
      var g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, w, h);
      var fd = null;
      try { var c0 = window.Akira && window.Akira.chains && window.Akira.chains[0]; var an = c0 && c0.nodes && c0.nodes.an; if (an && an.getByteFrequencyData) { fd = new Uint8Array(an.frequencyBinCount); an.getByteFrequencyData(fd); } } catch (x) {}
      var bl = Math.max(0, Math.min(1, (lastDb + 60) / 60)), N = bars.length, bw = w / N;
      for (var i = 0; i < N; i++) {
        var v = fd ? fd[Math.floor(i * fd.length * 0.55 / N)] / 255 : 0;
        v = Math.max(v, bl * (0.45 + 0.55 * Math.abs(Math.sin(ts / 170 + i * 0.8))));
        v = Math.max(v, 0.07 + 0.05 * Math.sin(ts / 420 + i * 0.5));
        bars[i] += (v - bars[i]) * 0.45;
        var bh = Math.max(2, bars[i] * (h - 3));
        var gr = g.createLinearGradient(0, h, 0, h - bh); gr.addColorStop(0, '#b026ff'); gr.addColorStop(1, '#ff2d64');
        g.fillStyle = gr; g.shadowColor = '#ff2d64'; g.shadowBlur = 6;
        g.fillRect(i * bw + 1, h - bh, Math.max(1, bw - 2), bh);
      }
      g.shadowBlur = 0;
    }
    // embers over the banner
    var ec = emCv, ew = ec.clientWidth, eh = ec.clientHeight;
    if (ew && eh) {
      if (ec.width !== ew) { ec.width = ew; ec.height = eh; }
      var e2 = ec.getContext('2d'); e2.clearRect(0, 0, ew, eh);
      while (embers.length < 26) embers.push({ x: Math.random() * ew, y: eh + Math.random() * eh, v: 14 + Math.random() * 34, r: 0.8 + Math.random() * 1.8, ph: Math.random() * 6.28, h: Math.random() < 0.7 ? 345 : 285 });
      for (var k = 0; k < embers.length; k++) {
        var m = embers[k]; m.y -= m.v * 0.033; m.x += Math.sin(ts / 600 + m.ph) * 0.35;
        if (m.y < -4) { m.y = eh + 4; m.x = Math.random() * ew; }
        var a = Math.max(0, Math.min(1, m.y / eh)) * 0.9;
        e2.fillStyle = 'hsla(' + m.h + ',100%,65%,' + a.toFixed(2) + ')'; e2.shadowColor = 'hsl(' + m.h + ',100%,60%)'; e2.shadowBlur = 8;
        e2.beginPath(); e2.arc(m.x, m.y, m.r, 0, 6.2832); e2.fill();
      }
      e2.shadowBlur = 0;
    }
  }

  /* ------------------------------------------------------------------ *
   *  HER VOICE: reacts when you switch tabs (hum / ahh / says the tab name)
   *  Local only: plays through the phone speaker, never into the call.
   * ------------------------------------------------------------------ */
  var sctx = null, lastReact = 0, capTimer = 0;
  function sc() {
    if (!sctx) { try { sctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return null; } }
    if (sctx.state === 'suspended') sctx.resume().catch(function () {});
    return sctx;
  }
  function voiceHum() {
    var c = sc(); if (!c) return; var t = c.currentTime;
    var out = c.createGain(); out.gain.value = 0; out.connect(c.destination);
    var o = c.createOscillator(); o.type = 'sawtooth';
    o.frequency.setValueAtTime(228, t); o.frequency.linearRampToValueAtTime(258, t + 0.32); o.frequency.linearRampToValueAtTime(214, t + 0.95);
    var vib = c.createOscillator(), vg = c.createGain(); vib.frequency.value = 5.6; vg.gain.value = 4; vib.connect(vg); vg.connect(o.frequency);
    var lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 650; lp.Q.value = 2.5;
    var nz = c.createBiquadFilter(); nz.type = 'peaking'; nz.frequency.value = 270; nz.gain.value = 10;
    o.connect(lp); lp.connect(nz); nz.connect(out);
    out.gain.linearRampToValueAtTime(0.2, t + 0.12); out.gain.setValueAtTime(0.2, t + 0.62); out.gain.linearRampToValueAtTime(0, t + 1.05);
    o.start(t); vib.start(t); o.stop(t + 1.1); vib.stop(t + 1.1);
  }
  function voiceAh() {
    var c = sc(); if (!c) return; var t = c.currentTime;
    var out = c.createGain(); out.gain.value = 0; out.connect(c.destination);
    var o = c.createOscillator(); o.type = 'sawtooth';
    o.frequency.setValueAtTime(285, t); o.frequency.linearRampToValueAtTime(232, t + 0.8);
    var vib = c.createOscillator(), vg = c.createGain(); vib.frequency.value = 5.2; vg.gain.value = 3.5; vib.connect(vg); vg.connect(o.frequency);
    [[800, 9, 1], [1220, 11, 0.55], [2600, 12, 0.22]].forEach(function (f) {
      var bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = f[0]; bp.Q.value = f[1];
      var gn = c.createGain(); gn.gain.value = f[2]; o.connect(bp); bp.connect(gn); gn.connect(out);
    });
    var nb = c.createBuffer(1, c.sampleRate * 0.9, c.sampleRate), d = nb.getChannelData(0); for (var i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    var ns = c.createBufferSource(); ns.buffer = nb; var hp = c.createBiquadFilter(); hp.type = 'bandpass'; hp.frequency.value = 1800; hp.Q.value = 0.8;
    var ng = c.createGain(); ng.gain.value = 0.05; ns.connect(hp); hp.connect(ng); ng.connect(out);
    out.gain.linearRampToValueAtTime(0.5, t + 0.07); out.gain.linearRampToValueAtTime(0.28, t + 0.5); out.gain.linearRampToValueAtTime(0, t + 0.95);
    o.start(t); vib.start(t); ns.start(t); o.stop(t + 1); vib.stop(t + 1); ns.stop(t + 1);
  }
  function speakName(name) {
    try {
      var ss = window.speechSynthesis; if (!ss || typeof SpeechSynthesisUtterance === 'undefined') return false;
      var u = new SpeechSynthesisUtterance(String(name).toLowerCase());
      u.pitch = 1.7; u.rate = 0.85; u.volume = 0.95;
      var vs = ss.getVoices ? ss.getVoices() : [], v = null;
      for (var i = 0; i < vs.length; i++) { if (/female|samantha|zira|en[-_]us/i.test(vs[i].name + ' ' + vs[i].lang)) { v = vs[i]; break; } }
      if (v) u.voice = v;
      var started = false; u.onstart = function () { started = true; }; u.onerror = function () { voiceAh(); };
      ss.cancel(); ss.speak(u);
      setTimeout(function () { if (!started && !ss.speaking) voiceAh(); }, 900);
      return true;
    } catch (e) { return false; }
  }
  function showCap(txt) {
    if (!capEl) return;
    capEl.textContent = txt; capEl.classList.add('show'); bannerEl.classList.add('talk');
    clearTimeout(capTimer); capTimer = setTimeout(function () { capEl.classList.remove('show'); bannerEl.classList.remove('talk'); }, 1300);
  }
  function react(label) {
    var now = Date.now(); if (now - lastReact < 250) return; lastReact = now;
    var r = Math.random(), cap;
    if (r < 0.3) { voiceHum(); cap = 'mhhmmmm…'; }
    else if (r < 0.6) { voiceAh(); cap = 'ahh~'; }
    else if (speakName(label)) { cap = label; }
    else { voiceAh(); cap = 'ahh~'; }
    showCap(cap);
    A.nodT = A.last; A.nextBlink = 0;                                  // nod + blink
  }
  document.addEventListener('click', function (e) {
    if (!panel || panel.style.display !== 'flex') return;
    var t = e.target && e.target.closest ? e.target.closest('.ak-tab,.bc-tab,#uni-modes button') : null;
    if (!t) return;
    var label = (t.textContent || '').replace(/\s+/g, ' ').trim();
    if (label) react(label);
  }, true);

  /* ------------------------------------------------------------------ *
   *  UI
   * ------------------------------------------------------------------ */
  var root, launcher, panel, view, mode = 'BLAKE', btnA, btnB, vizCv, emCv, capEl, bannerEl;
  var attached = { ak: false, bc: false };
  try { mode = localStorage.getItem('uni:mode') || mode; } catch (e) {}

  function el(tag, id, cls) { var e = document.createElement(tag); if (id) e.id = id; if (cls) e.className = cls; return e; }

  function activeBody() { return mode === 'AKIRA' ? document.getElementById('ak-body') : document.querySelector('#bc-panel .bc-body'); }

  function setMode(m) {
    mode = m; try { localStorage.setItem('uni:mode', m); } catch (e) {}
    var ak = document.getElementById('ak-pan'), bc = document.getElementById('bc-panel');
    if (ak) ak.classList.toggle('uni-on', m === 'AKIRA');
    if (bc) bc.classList.toggle('uni-on', m === 'BLAKE');
    btnA.classList.toggle('on', m === 'AKIRA'); btnB.classList.toggle('on', m === 'BLAKE');
  }

  function arrow(dir) {
    var b = el('div', null, 'uni-arr'); b.textContent = dir < 0 ? '▲' : '▼';
    var raf = 0, t0 = 0, held = false, last = 0;
    function loop(ts) {
      if (!held) return;
      var body = activeBody();
      if (body && ts - t0 > 220) { body.scrollTop += dir * Math.max(8, (ts - last) * 0.9); b.classList.add('hold'); }
      last = ts; raf = requestAnimationFrame(loop);
    }
    b.addEventListener('pointerdown', function (e) {
      e.preventDefault(); held = true; t0 = performance.now(); last = t0; try { b.setPointerCapture(e.pointerId); } catch (x) {}
      raf = requestAnimationFrame(loop);
    });
    function up() {
      if (!held) return; held = false; cancelAnimationFrame(raf); b.classList.remove('hold');
      if (performance.now() - t0 <= 220) { var body = activeBody(); if (body) body.scrollBy({ top: dir * Math.round(body.clientHeight * 0.8), behavior: 'smooth' }); }
    }
    b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('lostpointercapture', up);
    return b;
  }

  function open(o) {
    panel.style.display = o ? 'flex' : 'none';
    launcher.style.display = o ? 'none' : 'block';
    if (o && !fxRaf) fxRaf = requestAnimationFrame(fx);
  }

  function build() {
    if (document.getElementById('uni-root')) return;
    var st = document.createElement('style'); st.id = 'uni-css'; st.textContent = CSS;
    (document.head || document.documentElement).appendChild(st);

    root = el('div', 'uni-root');
    launcher = el('div', 'uni-launcher');
    var lc = document.createElement('canvas'); launcher.appendChild(lc);
    addPortrait(lc, { fx: 425, fy: 175, vw: 250, maxDpr: 2, par: 0.5 });

    panel = el('div', 'uni-panel');
    panel.style.setProperty('--pimg', 'url("' + PORT + '")');

    var banner = el('div', 'uni-banner');
    var bc = document.createElement('canvas'); banner.appendChild(bc);
    addPortrait(bc, { fx: 420, fy: 190, vw: 450, maxDpr: 2 });
    banner.appendChild(el('div', 'uni-scan'));
    var title = el('div', 'uni-title'); title.innerHTML = 'AKITAN<small>1ST PROJECT · MADE BY AKIRA</small>';
    var x = el('button', 'uni-x'); x.textContent = '✕';
    var em = document.createElement('canvas'); em.id = 'uni-embers'; banner.appendChild(em); emCv = em;
    capEl = el('div', 'uni-cap'); banner.appendChild(capEl);
    banner.appendChild(title); banner.appendChild(x); bannerEl = banner;

    var modes = el('div', 'uni-modes');
    btnA = document.createElement('button'); btnA.textContent = 'AKIRA';
    btnB = document.createElement('button'); btnB.textContent = 'BLAKE';
    btnA.addEventListener('click', function () { setMode('AKIRA'); });
    btnB.addEventListener('click', function () { setMode('BLAKE'); });
    modes.appendChild(btnA); modes.appendChild(btnB);

    var stage = el('div', 'uni-stage');
    view = el('div', 'uni-view');
    var sl = el('div', null, 'uni-side l'); sl.appendChild(arrow(-1)); sl.appendChild(arrow(1));
    var sr = el('div', null, 'uni-side r'); sr.appendChild(arrow(-1)); sr.appendChild(arrow(1));
    stage.appendChild(view); stage.appendChild(sl); stage.appendChild(sr);

    var tick1 = el('div', 'uni-ticker');
    var tx = '⚡ ULTIMATE GOD MODE ⚡ PC DESTROYER ⚡ AKITAN 1ST PROJECT ⚡ MADE BY AKIRA ⚡ ';
    tick1.innerHTML = '<div>' + tx + tx + tx + tx + '</div>';
    vizCv = el('canvas', 'uni-viz');
    panel.appendChild(banner); panel.appendChild(tick1); panel.appendChild(vizCv); panel.appendChild(modes); panel.appendChild(stage);
    root.appendChild(launcher); root.appendChild(panel);
    document.documentElement.appendChild(root);

    // launcher: tap to open, drag to move
    var drag = null;
    launcher.addEventListener('pointerdown', function (e) {
      var r = launcher.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top, sx: e.clientX, sy: e.clientY, moved: false };
      try { launcher.setPointerCapture(e.pointerId); } catch (x2) {}
    });
    launcher.addEventListener('pointermove', function (e) {
      if (!drag) return;
      if (Math.abs(e.clientX - drag.sx) + Math.abs(e.clientY - drag.sy) > 10) drag.moved = true;
      if (drag.moved) {
        launcher.style.right = 'auto'; launcher.style.bottom = 'auto';
        launcher.style.left = Math.max(0, Math.min(window.innerWidth - 68, e.clientX - drag.dx)) + 'px';
        launcher.style.top = Math.max(0, Math.min(window.innerHeight - 68, e.clientY - drag.dy)) + 'px';
      }
    });
    launcher.addEventListener('pointerup', function () { if (drag && !drag.moved) open(true); drag = null; });
    launcher.addEventListener('pointercancel', function () { drag = null; });
    x.addEventListener('click', function () { open(false); });

    setMode(mode);
  }

  /* host the two engine UIs inside the stage as soon as they exist */
  function adopt() {
    if (!view) return;
    var ar = document.getElementById('ak-root'), br = document.getElementById('bc-root');
    if (ar && ar.parentNode !== view) { view.appendChild(ar); attached.ak = true; }
    if (br && br.parentNode !== view) { view.appendChild(br); attached.bc = true; }
    // BlakeCord's boot screen: put the animated portrait behind its logo
    var boot = document.getElementById('bc-boot');
    if (boot && !boot.__uni) {
      boot.__uni = true;
      var cv = document.createElement('canvas');
      cv.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;opacity:.8;pointer-events:none';
      boot.insertBefore(cv, boot.firstChild);
      addPortrait(cv, { fx: 420, fy: 260, vw: 470, maxDpr: 1.5, zoom: 1 });
    }
    setMode(mode);
  }

  function start() {
    build();
    setInterval(adopt, 300);
    // Akira / Blake re-check timers: if either engine rebuilt its UI, adopt() picks it up again
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
