/* Makes Discord's browser check see a desktop Chrome (voice/calls are blocked on "mobile" browsers).
   Runs before blakecord-engine.js; does not touch the audio engine. */
(function () {
  try {
    var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36';
    function def(obj, prop, val) {
      try { Object.defineProperty(obj, prop, { get: function () { return val; }, configurable: true }); } catch (e) {}
    }
    var nav = Navigator.prototype;
    def(nav, 'userAgent', UA);
    def(nav, 'appVersion', UA.replace('Mozilla/', ''));
    def(nav, 'platform', 'Win32');
    def(nav, 'vendor', 'Google Inc.');
    var brands = [
      { brand: 'Chromium', version: '140' },
      { brand: 'Google Chrome', version: '140' },
      { brand: 'Not=A?Brand', version: '24' }
    ];
    var uad = {
      brands: brands, mobile: false, platform: 'Windows',
      getHighEntropyValues: function (hints) {
        return Promise.resolve({
          brands: brands, mobile: false, platform: 'Windows', platformVersion: '10.0.0',
          architecture: 'x86', bitness: '64', model: '', uaFullVersion: '140.0.0.0',
          fullVersionList: [
            { brand: 'Chromium', version: '140.0.0.0' },
            { brand: 'Google Chrome', version: '140.0.0.0' }
          ]
        });
      },
      toJSON: function () { return { brands: brands, mobile: false, platform: 'Windows' }; }
    };
    def(nav, 'userAgentData', uad);
  } catch (e) {}
})();
