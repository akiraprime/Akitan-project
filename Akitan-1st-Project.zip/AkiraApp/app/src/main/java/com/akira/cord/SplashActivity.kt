package com.akira.cord

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity

/** Opening animation (assets/intro.html). Tap anywhere to skip. */
class SplashActivity : AppCompatActivity() {
    private var finished = false
    private val handler = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#050208"))
        web.settings.javaScriptEnabled = true
        web.addJavascriptInterface(IntroBridge(), "AkiraIntro")
        setContentView(web)
        web.loadUrl("file:///android_asset/intro.html")
        handler.postDelayed({ goNext() }, 6000) // safety net if the page never reports back
    }

    private fun goNext() {
        if (finished) return
        finished = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    inner class IntroBridge {
        @JavascriptInterface
        fun done() {
            runOnUiThread { goNext() }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
