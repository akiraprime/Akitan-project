package com.akira.cord

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

/**
 * Discord web in a WebView. The Akira engine (assets/blakecord-engine.js) is injected before the page runs,
 * hooks the microphone, and draws the tabbed Akira panel on top of Discord.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    // injected into Discord in this order: desktop identity, portrait data, Akira engine, BlakeCord engine, unified GUI
    private var scripts: List<String> = emptyList()
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { startVoiceService() }

    private val fileLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        val data = res.data
        val uris: Array<Uri>? = if (res.resultCode == Activity.RESULT_OK && data != null) {
            val clip = data.clipData
            when {
                clip != null -> Array(clip.itemCount) { clip.getItemAt(it).uri }
                data.data != null -> arrayOf(data.data!!)
                else -> null
            }
        } else null
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#050208")
        window.navigationBarColor = Color.parseColor("#050208")

        scripts = listOf(
            "ua-patch.js", "portrait-data.js", "akira-engine.js", "blakecord-engine.js", "unified-shell.js"
        ).map { name -> assets.open(name).bufferedReader().use { it.readText() } }

        web = WebView(this)
        web.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        web.setBackgroundColor(Color.parseColor("#313338"))
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.allowFileAccess = false
        s.setSupportZoom(false)
        s.userAgentString = DESKTOP_UA

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        // Inject the engine before Discord's own scripts run (preferred), with a fallback.
        var docStart = false
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try {
                val origins = setOf("https://discord.com", "https://*.discord.com")
                scripts.forEach { WebViewCompat.addDocumentStartJavaScript(web, it, origins) }
                docStart = true
            } catch (e: Exception) {
                docStart = false
            }
        }
        val useFallback = !docStart

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                if (useFallback && url != null && url.contains("discord.com")) {
                    scripts.forEach { view.evaluateJavascript(it, null) }
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val scheme = u.scheme ?: return false
                if (scheme == "http" || scheme == "https") return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                    true
                } catch (e: Exception) {
                    true
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val ok = request.resources.all { r ->
                        when (r) {
                            PermissionRequest.RESOURCE_AUDIO_CAPTURE -> has(Manifest.permission.RECORD_AUDIO)
                            PermissionRequest.RESOURCE_VIDEO_CAPTURE -> has(Manifest.permission.CAMERA)
                            else -> true
                        }
                    }
                    if (ok) request.grant(request.resources) else request.deny()
                }
            }

            override fun onShowFileChooser(
                view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try {
                    fileLauncher.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else moveTaskToBack(true)
            }
        })

        askPermissions()
        web.loadUrl("https://discord.com/app")
    }

    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun askPermissions() {
        val want = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) want.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 31) want.add(Manifest.permission.BLUETOOTH_CONNECT)
        val missing = want.filter { !has(it) }
        if (missing.isEmpty()) startVoiceService() else permLauncher.launch(missing.toTypedArray())
    }

    private fun startVoiceService() {
        if (!has(Manifest.permission.RECORD_AUDIO)) return
        try {
            ContextCompat.startForegroundService(this, Intent(this, VoiceService::class.java))
        } catch (e: Exception) {
            // not fatal: the app still works, it just can't keep the mic alive in the background
        }
    }

    override fun onDestroy() {
        stopService(Intent(this, VoiceService::class.java))
        web.destroy()
        super.onDestroy()
    }

    companion object {
        private const val DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/140.0.0.0 Safari/537.36"
    }
}
